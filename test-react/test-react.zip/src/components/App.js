import React, { Component } from 'react';
import './App.css';

import RegistrationForm from "./RegistrationForm";
import OutputCourse from "./OutputCourse";

class App extends Component {

    constructor(props){
        super(props);

        this.state={
            courseList: [],
            singleCourse: {
                author: "",
                course: "",
                details: ""
            },
            isSubmit: false
        };

        this.handleReset=this.handleReset.bind(this);
        this.handleSubmit=this.handleSubmit.bind(this);
        this.handleChange=this.handleChange.bind(this);
    }

    handleReset(e){
        e.preventDefault();
        this.setState({
            ...this.state,
            singleCourse: {
                author: "",
                course: "",
                details: ""
            },
            isSubmit: false
        });
        console.log("reset button clicked!");
    }

    handleSubmit(e){
        e.preventDefault();
        this.setState({
            ...this.state,
            courseList: [this.state.singleCourse, ...this.state.courseList],
            singleCourse: {
                author: "",
                course: "",
                details: ""
            },
            isSubmit: true
        });
        console.log("submit button clicked!");
    }

    handleChange(e){
        console.log(e.target);
        this.setState({
            ...this.state,
            singleCourse: {
                ...this.state.singleCourse,
                [e.target.name]: e.target.value
            },
            isSubmit: false
        });
    }

    render() {
        return (
            <div className="App">
                <div>
                    <RegistrationForm
                        handleReset={this.handleReset}
                        handleSubmit={this.handleSubmit}
                        handleChange={this.handleChange}
                    />
                </div>
                <div><OutputCourse courses={this.state.courseList}  /></div>
            </div>
        );
    }
}

export default App;
