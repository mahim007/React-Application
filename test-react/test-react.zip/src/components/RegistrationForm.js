import React from "react";

const RegistrationForm = (props) => {
    return(
        <div>
            <form>
                <div className="row form-group">
                    <label className="col-sm-5 text-right" htmlFor="autor">Author: </label>
                    <input onChange={props.handleChange} className="col-sm-3 form-control" name="author" type="text"/>
                </div>
                <div className="row form-group">
                    <label className="col-sm-5 text-right" htmlFor="course">Course: </label>
                    <input onChange={props.handleChange} className="col-sm-3 form-control" name="course" type="text"/>
                </div>
                <div className="row form-group">
                    <label className="col-sm-5 text-right" htmlFor="details">Details: </label>
                    <input onChange={props.handleChange} className="col-sm-3 form-control" name="details" type="text"/>
                </div>
                <div>
                    <button
                        onClick={props.handleReset}
                        className="btn btn-danger mx-3">Reset</button>

                    <button
                        onClick={props.handleSubmit}
                        className="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    );
};

export default RegistrationForm;